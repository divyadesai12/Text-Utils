
from django.http import HttpResponse
from django.shortcuts import render 
import titlecase



def index(request): 
    
    return render(request,'index.html') 

def about(request):
    return render(request,'about.html')

def contact(request):
    email=request.GET.get('email')
    meg=request.GET.get('message')

    if email!="" and meg!="":

        infos='Your information is suucessful send!'
        pamar={'info':infos}
        return render(request,'contact.html',pamar)
        

def analyze(request):
    
    djtext=request.POST.get('text','default') 
    removepunc=request.POST.get('removepunc','off')
    fullcaps=request.POST.get('fullcaps','off')
    newlineremove=request.POST.get('newlineremove','off')
    spaceremove=request.POST.get('spaceremove','off')
    charcounter=request.POST.get('charcounter','off')
    lowercase=request.POST.get('lowercase','off')
    reversetext=request.POST.get('reversetext','off')
    extracttext=request.POST.get('extracttext','off')
    sentencecase=request.POST.get('sentencecase','off')
    extractnumber=request.POST.get('extractnumber','off')
   
    if removepunc == "on":
        
        punctuations=''' !()-[]{};:'"\,<>./?@#$%^&*_~= '''
        analyzed=""
        for char in djtext:
            if char not in punctuations:
                analyzed=analyzed+char

       
        params={'analyzed_text':analyzed}
        djtext=analyzed
        
    
    if fullcaps == "on":
        analyzed=""
        for char in djtext:
            analyzed+=char.upper()

        params={'analyzed_text':analyzed}
        djtext=analyzed
        
    
    if lowercase=="on":
        analyzed=""
        for char in djtext:
            analyzed+=char.lower()
        
        params={'analyzed_text':analyzed}
        djtext=analyzed
        


    if newlineremove == "on":
        analyzed=""
        for char in djtext:
            if char!="\n" and char!="\r":
                analyzed+=char
        params={'analyzed_text':analyzed}
        djtext=analyzed
        
    if spaceremove == "on":
        analyzed=""
        for index,char in enumerate(djtext):
            if not (djtext[index]==" " and djtext[index+1]==" "):
                analyzed+=char
            
        params={'analyzed_text':analyzed}
        djtext=analyzed
        

    if charcounter == "on":
        analyzed=0
        
        for char in range(0,len(djtext)):
            if(djtext[char]!=''):
                analyzed=analyzed+1 
        params={'analyzed_text':analyzed}
        djtext=analyzed
    
    if reversetext == "on":
        analyzed=""
        for char in djtext:
            analyzed=char+analyzed

        params={'analyzed_text':analyzed}
        djtext=analyzed
        
    if extracttext=="on":
        analyzed=""
        for char in djtext:
            analyzed=analyzed+''.join(filter(lambda x: not x.isdigit(), char))

        params={'analyzed_text':analyzed}
        djtext=analyzed
    
    if sentencecase =="on":
        copy=djtext
        analyzed=""
        analyzed+=copy.title()

        params={'analyzed_text':analyzed}
        djtext=analyzed

    if extractnumber=="on":
        analyzed=""
        
        for char in djtext:
            analyzed=analyzed+''.join(filter(lambda i: i.isdigit(), char))

        params={'analyzed_text':analyzed}

        
    if(removepunc!="on" and fullcaps!="on" and lowercase!="on" and newlineremove!="on" and spaceremove!="on" and charcounter!="on" and reversetext!="on" and extracttext!="on" and sentencecase!="on" and extractnumber!="on"):
        return HttpResponse("<h1>Error!</h1><h2>Please select any operations and try again.</h2>") 
    
  
    return render(request,'index.html',params)
    

    














